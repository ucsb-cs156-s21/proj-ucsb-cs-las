import React from 'react';

import AppFooter from "main/components/Footer/AppFooter";

export default {
  title: 'components/Footer/AppFooter',
  component: AppFooter
};

const Template = () => <AppFooter />;

export const Empty = Template.bind({});

