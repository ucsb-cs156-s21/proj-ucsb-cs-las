import React from "react";
import { render } from "@testing-library/react";
import CourseDetailOfficeHours from "main/components/Courses/CourseDetailOfficeHours.js";

describe("Course Detail Office Hours component test", () => {

  test("renders without crashing", () => {
    render(<CourseDetailOfficeHours />);
  });



});


