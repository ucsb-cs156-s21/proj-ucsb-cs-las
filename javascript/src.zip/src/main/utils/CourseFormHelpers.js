function checkEmail(email) {
    return email.endsWith("@ucsb.edu");
}


export { checkEmail };